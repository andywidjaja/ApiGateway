﻿// Copyright (c) Brock Allen & Dominick Baier. All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.

using IdentityModel;
using IdentityServer4;
using IdentityServer4.Models;
using System.Collections.Generic;

namespace QuickstartIdentityServer
{
    public class InMemoryInitConfig
    {
        public const string IdentityHost = "http://localhost:9010";

        // scopes define the resources in your system
        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new List<IdentityResource>
            {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
                new IdentityResource
                {
                    Name = JwtClaimTypes.Role,
                    DisplayName = "User Active Directory roles",
                    UserClaims = { JwtClaimTypes.Role }
                }
            };
        }

        public static IEnumerable<ApiResource> GetApiResources()
        {
            return new List<ApiResource>
            {
                // To-do API
                new ApiResource("todo-api", "Sample Todo API Client"),
                // Bond API
                new ApiResource("bond-api", "Bond API")
            };
        }

        public static IEnumerable<Client> GetClients()
        {
            return new List<Client>
            {
                // To-do ASP.NET MVC client
                new Client
                {
                    ClientId = "Platform.WebClient",
                    ClientName = "WebApp MVC Client",
                    ClientSecrets = { new Secret("webclient-secret".Sha256()) },

                    AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
                    AllowOfflineAccess = true,
                    
                    // === 'false' for trusted platform clients so the user will not have to accept the application
                    RequireConsent = false,

                    RedirectUris = { "http://localhost:9012/signin-oidc" }, // Url of the WebApp Client
                    BackChannelLogoutUri = "http://localhost:9012/signout-oidc",
                    PostLogoutRedirectUris = { "http://localhost:9012/signout-callback-oidc" }, // Url of the WebApp Client
                    
                    AllowedScopes =
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        JwtClaimTypes.Role,
                        "todo-api"
                    }
                },

                // Bond API web SPA client
                new Client
                {
                    ClientId = "spa-client",
                    ClientName = "SPA Client",

                    AllowedGrantTypes = GrantTypes.Implicit,
                    AllowAccessTokensViaBrowser = true,
                    
                    // === 'false' for trusted clients so the user will not have to accept the application
                    RequireConsent = false,

                    RedirectUris =           { "http://localhost:8012/assets/oidc-login-redirect.html","http://localhost:8012/assets/silent-redirect.html" },
                    PostLogoutRedirectUris = { "http://localhost:8012/?postLogout=true" },
                    AllowedCorsOrigins =     { "http://localhost:8012/" },

                    AllowedScopes =
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        JwtClaimTypes.Role,
                        "bond-api"
                    },

                    IdentityTokenLifetime = 900,
                    AccessTokenLifetime = 900
                }
            };
        }
    }
}