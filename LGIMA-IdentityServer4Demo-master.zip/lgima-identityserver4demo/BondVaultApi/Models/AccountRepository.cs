using System.Threading.Tasks;

using BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_BaseApiSDK;

namespace BondVaultApi.Models
{
    public class AccountRepository : IAccountRepository
    {
        private readonly IRestApiHttpClient _restApiHttpClient;

        public AccountRepository(IRestApiHttpClient restApiHttpClient)
        {
            _restApiHttpClient = restApiHttpClient;
        }

        public Task<UserProfile> Load(string token)
        {
            // Set header bearer token
            var bearerAuthorizedApiClient = _restApiHttpClient as BearerAuthorizedApiClient;
            bearerAuthorizedApiClient.SetBearerToken(token);

            var userInfo = _restApiHttpClient.GetFromApiAsync<UserProfile>("http://localhost:9010/connect/userinfo");

            return userInfo;
        }
    }
}