﻿using System.Collections.Generic;

namespace BondVaultApi.Models
{
    public class AuthContext
    {
        public List<SimpleClaim> Claims { get; set; }

        public UserProfile UserProfile { get; set; }
    }
}