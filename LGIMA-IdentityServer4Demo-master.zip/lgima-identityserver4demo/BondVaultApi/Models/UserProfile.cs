﻿namespace BondVaultApi.Models
{
    public class UserProfile
    {
        public string name { get; set; }
        public string family_name { get; set; }
        public string given_name { get; set; }
        public string[] role { get; set; }
        public string sub { get; set; }
    }
}
