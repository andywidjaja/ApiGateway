using System.Threading.Tasks;

namespace BondVaultApi.Models
{
    public interface IAccountRepository
    {
        Task<UserProfile> Load(string token);
    }
}