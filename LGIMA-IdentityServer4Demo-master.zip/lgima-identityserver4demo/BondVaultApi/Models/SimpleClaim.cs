﻿namespace BondVaultApi.Models
{
    public class SimpleClaim
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}