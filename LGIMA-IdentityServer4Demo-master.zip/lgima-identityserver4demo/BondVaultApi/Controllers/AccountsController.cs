﻿using System.Threading.Tasks;

using BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_BaseApiSDK;
using BondVaultApi.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BondVaultApi.Controllers
{
    [Route("api/[controller]")]
    public class AccountsController : Controller
    {
        private readonly IRestApiHttpClient _restApiHttpClient;

        private readonly IAccountRepository _accountRepository;

        public AccountsController(IRestApiHttpClient restApiHttpClient, IAccountRepository accountRepository)
        {
            _restApiHttpClient = restApiHttpClient;
            _accountRepository = accountRepository;
        }

        [HttpGet("AuthContext")]
        [Authorize()]
        public async Task<IActionResult> GetAuthContext()
        {
            // Get user access token from http context (SPA client)
            var accessToken = await HttpContext.GetTokenAsync("access_token");

            // This is how to get LGIM user Id
            //var subject = HttpContext.User.Claims.FirstOrDefault(c => c.Type == "sub");
            //var userId = subject.Value;

            //var bearerAuthorizedApiClient = _restApiHttpClient as BearerAuthorizedApiClient;
            //bearerAuthorizedApiClient.SetBearerToken(accessToken);
            //var userInfo = await _restApiHttpClient.GetFromApiAsync<UserProfile>("http://localhost:9010/connect/userinfo");
            var userInfo = await _accountRepository.Load(accessToken);

            var context = new AuthContext { UserProfile = userInfo }; //, Claims = User.Claims.Select(c => new SimpleClaim { Type = c.Type, Value = c.Value }).ToList() };

            return Ok(context);
        }
    }
}