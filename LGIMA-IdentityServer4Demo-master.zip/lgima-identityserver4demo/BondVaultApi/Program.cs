﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;

using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace BondVaultApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args)
        {
            //var host = Dns.GetHostEntry(Dns.GetHostName());
            //var addressList = new List<string>
            //{
            //    //"http://localhost:8011",
            //    "http://0.0.0.0:8011"
            //    //$"http://{Environment.MachineName}:8011"
            //};

            //foreach (var ip in host.AddressList)
            //{                
            //    if (ip.AddressFamily == AddressFamily.InterNetwork)
            //    {
            //        addressList.Add($"http://{ip.ToString()}:8011");
            //    }
            //}

            return WebHost.CreateDefaultBuilder(args)
                //.UseUrls(addressList.ToArray())
                .UseStartup<Startup>();
        }            
    }
}