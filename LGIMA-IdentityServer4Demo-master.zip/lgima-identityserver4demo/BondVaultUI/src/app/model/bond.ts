export class Bond {
    cusip: string;

    assetType: string;

    issuerIndustry: string;

    mortgageAmortizationTypeLevel: number;

    mortgageType: string;

    mortgagePrepayType: string;

    securityType: string;

    securityType2: string;

    couponType: string;

    marketSectorDescription: string;

    mortgageCollateralType: string;

    taxCode: string;

    bankQualified: string;

    datedDate: Date;

    capitalPurpose: string;
}