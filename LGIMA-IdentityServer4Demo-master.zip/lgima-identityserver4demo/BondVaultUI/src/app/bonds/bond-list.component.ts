import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { Utils } from '../core/utils';
import { BondService } from '../core/bond.service';
import { Bond } from '../model/bond';

@Component({
    selector: 'app-bonds',
    templateUrl: 'bond-list.component.html'
})

export class BondListComponent implements OnInit {
    error: string;
    displayedColumns = ['cusip', 'assetType', 'issuerIndustry'];
    dataSource = new MatTableDataSource();
    bonds: Bond[];

    constructor(private bondService: BondService) {
    }

    ngOnInit() {
        this.bondService.getAllBonds().subscribe(bonds => {
            this.bonds = bonds;
            this.dataSource.data = bonds;
        }, error => Utils.formatError(error));
    }
}