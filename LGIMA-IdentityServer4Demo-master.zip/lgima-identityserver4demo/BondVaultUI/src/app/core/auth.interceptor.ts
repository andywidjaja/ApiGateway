import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { Constants } from '../constants';
import { Router } from '@angular/router';

@Injectable({providedIn: 'root'})
export class AuthInterceptor implements HttpInterceptor {
    constructor(private _authService: AuthService, private _router: Router) {
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (req.url.startsWith(Constants.apiRoot)) {
            var accessToken = this._authService.getAccessToken();
            const headers = req.headers.set('Authorization', `Bearer ${accessToken}`);
            console.log(`Access token:  + ${accessToken}`);
            const authReq = req.clone({ headers });
            return next.handle(authReq);
        }

        return next.handle(req);
    }
}
