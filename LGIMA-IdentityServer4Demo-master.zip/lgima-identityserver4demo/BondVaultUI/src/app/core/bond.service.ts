import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';
import { HttpClient } from "@angular/common/http";
import { Constants } from "../constants";
import { Bond } from "../model/bond";

@Injectable()
export class BondService {
    constructor(private httpClient: HttpClient) {
    }

    getAllBonds(): Observable<Bond[]> {
        let bondList = this.httpClient.get<Bond[]>(Constants.apiRoot + 'bonds');

        //console.log(bondList);

        return bondList;
    }
}
