export class Constants {
    public static apiRoot = 'http://localhost:8011/api/';
    public static stsAuthority = 'http://localhost:9010/';

    public static clientId = 'spa-client';

    public static clientRoot = 'http://localhost:8012/';
}