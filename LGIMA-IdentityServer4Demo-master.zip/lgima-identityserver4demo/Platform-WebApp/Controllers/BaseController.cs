﻿using Microsoft.AspNetCore.Mvc;

namespace BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_PortalWebApp.Controllers
{
    public abstract class BaseController : Controller {}
}