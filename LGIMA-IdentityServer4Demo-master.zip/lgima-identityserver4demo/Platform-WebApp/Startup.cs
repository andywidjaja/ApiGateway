﻿using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

using BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_BaseApiSDK;
using BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApiSdk;
using IdentityModel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth.Claims;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_PortalWebApp
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();

            services.AddAuthentication(options =>
                {
                    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
                })
                .AddCookie()
                .AddOpenIdConnect(
                    options =>
                    {
                        // === FOR DEMO ONLY
                        options.RequireHttpsMetadata = false;
                        // SET THIS TO true IN PRODUCTION!

                        options.GetClaimsFromUserInfoEndpoint = true;
                        options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;

                        options.Authority = PortalWebAppOptions.IdentityServerHost;
                        options.ClientId = PortalWebAppOptions.ClientId;
                        options.ClientSecret = PortalWebAppOptions.ClientSecret;

                        options.ResponseType = "code id_token";
                        options.SaveTokens = true;
                    
                        options.Scope.Add("todo-api");
                        options.Scope.Add(JwtClaimTypes.Role);

                        // The only way to get user AD roles added automatically to HttpContext.User.Claims
                        // https://github.com/aspnet/Security/issues/1449
                        //
                        // The problem with this is LGIM AD roles can be really big and would exceed cookie size limitation
                        options.ClaimActions.Add(new JsonKeyArrayClaimAction(JwtClaimTypes.Role, JwtClaimTypes.Role, JwtClaimTypes.Role));
                    }
                );

            services.AddMvc();

            // Todo API Settings

            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            // singleton is safe here, see https://github.com/aspnet/Hosting/issues/793

            services.AddTransient<IRestApiHttpClient, AspNetCoreHttpContextBearerAuthorizedApiClient>();
            services.AddTransient<TodoApiClient>(x =>
                new TodoApiClient(x.GetService<IRestApiHttpClient>(), PortalWebAppOptions.TodoApiUrl));
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseDeveloperExceptionPage();

            app.UseAuthentication();

            app.UseMvcWithDefaultRoute();
        }
    }
}
