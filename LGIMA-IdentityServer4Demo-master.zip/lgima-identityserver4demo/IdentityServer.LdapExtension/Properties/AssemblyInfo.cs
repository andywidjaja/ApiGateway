﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("IdentityServer.LdapExtension.Unit")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
