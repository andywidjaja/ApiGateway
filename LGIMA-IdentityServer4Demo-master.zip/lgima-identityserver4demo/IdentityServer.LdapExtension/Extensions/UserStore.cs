﻿namespace IdentityServer.LdapExtension.Extensions
{
    public enum UserStore
    {
        InMemory,
        Redis
    }
}
