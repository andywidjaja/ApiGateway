# LGIMA-IdentityServer4Demo

This demo .NET Core-based solution demonstrates Identity Server 4 capabilities to provide authentication and authorization service (Compliant with OpenID and OAuth 2.0 specifications) to 2 separate mini demo applications.  Each mini demo application has a UI and a back-end API secured with its own API key.  Accessing the demo application from the UI that requires supporting data from its back end API would trigger a OpenID style authentication and OAuth 2.0 style authorization.  Upon a user logs in successfully, Identity Server would return a valid identity token and an access token for UI client application to access its back-end API service.

More importantly, Identity Server 4 should provide a Single Sign On (SSO) capability to LGIMA applications that support OpenID and OAuth 2.0.

## Getting Started

These instructions will get you a copy of the solution up and running on your local machine for development and testing purposes.  Further steps need to be taken for production quality deployment.

### Prerequisites

Many of these items below should already be available after you run LGIMA-DevCopy powershell script and configurations: https://gogs.btprod.openshift.inv.adroot.lgim.com/lgima/LGIMA-DevCopy

```
Visual Studio 2017 (Via your own MSDN subscription)
Visual Studio Code(https://code.visualstudio.com/)
.NET Core 2.0 and 2.1 SDK (https://www.microsoft.com/net/download/dotnet-core/2.1)
Node.js (https://nodejs.org/en/)
Angular CLI (https://cli.angular.io/)
```

## Running the Demo Solution

Open IdentityServer4Demo solution in Visual Studio 2017 to view the projects below.  The .NET solution should already have been configured to start up multiple projects simultaneously when you press F5 (Run in debug mode) in Visual Studio.  When you are presented with the login screen, use your corporate LGIMA Windows credential to authenticate against LGIM Active Directory.

### QuickStartIdentityServer

Identity Server 4 host service (Port 9010).  All configurations like user repository, API's, and clients are currently hard coded in InMemoryInitConfig.cs

Identity Server is registered inside Startup.cs

Source code is based on Identity Server 4 sample code posted at GitHub (https://github.com/IdentityServer/IdentityServer4.Quickstart.UI)

### IdentityServer.LdapExtension

Identity server LDAP extension is necessary due to the plan to deploy these services as containers hosted in LINUX OS.  LDAP communication is required to authenticate a Windows user between Linux and LGIM Windows Active Directory.

### BondVaultApi

Bond Vault API service (Port 8011).  It provides bonds indicative data (i.e. cusip, asset type, etc.) for demo purposes.

The front end is SPA written in Angular 6.0 and should be opened separately in Visual Studio Code.

### TodoApi

To-do API service (Port 9011).  It provides dummy to-do list for demo purposes.

### Todo PortalWebApp

Listening on port 9012, this ASP.NET Core 2.0 application represents the "Portal Web Application" the user interacts with.

You have a navigation element to receive the tasks from the TodoApi with the help of the TodoApiSdk and you have a navigation element to watch your claims.

Both clicks will redirects you to the IdentityServerHost where you have to log in. Afterwards to will be redirected to this application.

### Todo BaseApiSDK

Helper project for Todo demo application.


### Bond Vault UI

Open Bond Vault UI project in Visual Studio Code and from its integrated terminal type in "ng serve --port 8012" to launch the Angular SPA client and bind it to port 8012.


## Further reading:

OpenID & OAuth 2.0 in plain English: https://www.youtube.com/watch?v=996OiexHze0

Identity Server 4: http://docs.identityserver.io/en/release/intro/big_picture.html

Identity Server 4 demo: https://www.youtube.com/watch?v=J5p72gTdx_M

Identity Server 4 LDAP extension: https://github.com/Nordes/IdentityServer4.LdapExtension

JavaScript library to support OpenID & OAuth 2.0 in browser-based client application (i.e. Angular): https://github.com/IdentityModel/oidc-client-js

JWT (JSON Web Token) debugger by a commerical identity provider vendor, OAuth0: https://jwt.io/