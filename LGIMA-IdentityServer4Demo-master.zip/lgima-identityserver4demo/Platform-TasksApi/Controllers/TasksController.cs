﻿using System.Threading.Tasks;

using BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApiSdk.ApiModels;
using BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class TasksController : Controller
    {
        private readonly ITaskRepository _taskRepository;

        public TasksController(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        [HttpGet]
        [Route("")]
        public async Task<IActionResult> GetAsync()
        {
            var taskList = _taskRepository.LoadAll();
            IActionResult result = Ok(taskList);

            return await Task.FromResult(result);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var task = _taskRepository.Load(id);
            if (task == null)
            {
                return NotFound();
            }

            return Ok(task);
        }

        [HttpPost]
        public void Post([FromBody] TaskApiModel task)
        {
            _taskRepository.Add(task);

            //return CreatedAtRoute("GetById", new { id = newTaskId }, newTask);
        }
    }
}