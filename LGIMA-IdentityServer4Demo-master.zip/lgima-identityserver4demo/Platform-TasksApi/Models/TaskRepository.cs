using System.Collections.Generic;
using System.Linq;

using BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApiSdk.ApiModels;

namespace BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApi.Models
{
    public class TaskRepository : ITaskRepository
    {
        private List<TaskApiModel> _taskList;

        public TaskRepository()
        {
            _taskList = new List<TaskApiModel>()
            {
                new TaskApiModel(1, "Update GitHub", "Lorem ipsum"),
                new TaskApiModel(2, "Write BlogPost", "Lorem ipsum"),
                new TaskApiModel(3, "Follow LGIMA on Twitter", "Lorem ipsum")
            };
        }

        public void Add(TaskApiModel task)
        {
            var newTaskId = _taskList.Max(t => t.Id);
            var newTask = new TaskApiModel(++newTaskId, task.Title, task.Description);

            _taskList.Add(newTask);
        }

        public TaskApiModel Load(int id)
        {
            return _taskList.FirstOrDefault(t => t.Id == id);
        }

        public IEnumerable<TaskApiModel> LoadAll()
        {
            return _taskList;
        }

        public void Remove(int id)
        {
        }

        public void Update(int id, TaskApiModel task)
        {
        }
    }
}