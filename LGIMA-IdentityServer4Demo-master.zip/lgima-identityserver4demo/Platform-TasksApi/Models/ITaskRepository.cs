using System.Collections.Generic;

using BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApiSdk.ApiModels;

namespace BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApi.Models
{
    public interface ITaskRepository
    {
        void Add(TaskApiModel task);

        TaskApiModel Load(int id);

        IEnumerable<TaskApiModel> LoadAll();

        void Remove(int id);

        void Update(int id, TaskApiModel task);
    }
}