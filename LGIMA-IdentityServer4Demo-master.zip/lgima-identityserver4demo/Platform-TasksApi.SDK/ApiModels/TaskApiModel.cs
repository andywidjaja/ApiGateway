﻿namespace BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_TodoApiSdk.ApiModels
{
    public class TaskApiModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

        public TaskApiModel(int id, string title, string description)
        {
            Id = id;
            Title = title;
            Description = description;
        }
    }
}