﻿using System.Net.Http.Headers;

namespace BenjaminAbt.Samples.AspNetCore_IdentityServer.Platform_BaseApiSDK
{
    public class BearerAuthorizedApiClient : RestApiHttpClient
    {
        public BearerAuthorizedApiClient()
        {
        }

        public BearerAuthorizedApiClient(string token)
        {
            this.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        public void SetBearerToken(string token)
        {
            DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
    }
}